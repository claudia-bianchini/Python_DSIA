import dash
from dash import dcc, html
from dash.dependencies import Input, Output
import pandas as pd
import folium
from branca.colormap import LinearColormap
from collections import defaultdict
import plotly.express as px
import io
import base64
import plotly.graph_objects as go


from plotly.subplots import make_subplots

# Map functions
def generate_colormaps(df, variables):
    """
    Generate LinearColormap for numeric columns in the DataFrame.

    Args:
    - df (pd.DataFrame): The DataFrame.
    - variables (list): List of column names.

    Returns:
    - dict: A dictionary containing LinearColormap objects for each numeric column.
    """
    colormaps = {}
    for column in df.columns:
        if column in variables and df[column].dtype in [int, float]:
            # Assuming numeric columns should have a LinearColormap
            colormaps[column] = LinearColormap(['purple', 'blue', 'yellow', 'orange', 'red'], vmin=df[column].min(), vmax=df[column].max())
    return colormaps


# Define a function to create the map
def create_map(df, color_dict, colormap, selected_var, variable_details):
    """
    Create a Folium map based on the provided DataFrame and color information.

    Args:
    - df (pd.DataFrame): The DataFrame containing geographical data.
    - color_dict (dict): Dictionary with unique coordinates as keys and associated colors as values.
    - colormap: LinearColormap object representing the colors for the selected variable.
    - selected_var (str): The selected variable for color representation.
    - variable_details (dict): Details about the variables.

    Returns:
    - str: HTML representation of the Folium map.
    """
    if not df.empty:
        m = folium.Map(
            location=[df.iloc[1]['latitude'], df.iloc[1]['longitude']],
            zoom_start=7
        )

        for index, row in df.iterrows():
            unique_pair = (row['latitude'], row['longitude'])
            color = color_dict.get(unique_pair, 'green')

            folium.CircleMarker(
                location=unique_pair,
                popup=f"Name municìpios: {row['name_ibge']}",
                radius=10,
                color=color,
                fill=True,
                fill_color=color,
                fill_opacity=0.2,
                line_opacity=0.8,
            ).add_to(m)

        # Add the colormap to the map
        colormap.add_to(m)
        colormap.caption = f'{selected_var} '#- {variable_details[selected_var][0]} [{variable_details[selected_var][1]}]'

        # Define a custom HTML legend
        legend_html = """
        <div style="position: fixed; bottom: 50px; left: 50px; width: 220px; z-index:1000; background-color: white; padding: 10px; border: 1px solid grey;">
            <p><strong>Legend</strong></p>
            <p>CircleMarker Radius:</p>
            <p style="font-size: 12px;">Radius is proportional to Productivity.</p>
        </div>
        """

        # Add the custom HTML legend to the map
        m.get_root().html.add_child(folium.Element(legend_html))
        folium.map.LayerControl('topleft', collapsed=False).add_to(m)

        # Convert the Folium map to an HTML string
        map_html = m.get_root().render()
        return map_html 
    else:
        print("DataFrame is empty, cannot create the map.")
        return None
    

def update_map(df, selected_year, selected_month, selected_day, selected_var, variable_details, colormap):
    """
    Update the Folium map based on selected options.

    Args:
    - df (pd.DataFrame): The DataFrame with geographical data.
    - selected_year (str): Selected year.
    - selected_month (str): Selected month.
    - selected_day (str): Selected day.
    - selected_var (str): Selected variable for color representation.
    - variable_details (dict): Details about the variables.
    - colormap: LinearColormap object representing the colors for the selected variable.

    Returns:
    - str: HTML representation of the updated Folium map.
    """
    df['year'] = df['year'].astype(str)
    df['month'] = df['month'].astype(str)
    df['day'] = df['day'].astype(str)

    filtered_data = df[
        (df['year'] == selected_year) &
        (df['month'] == selected_month) &
        (df['day'] == selected_day)
    ]

    color_dict_filtered = defaultdict(str)
    if not filtered_data.empty:
        for index, row in filtered_data.iterrows():
            color = colormap[selected_var](row[selected_var])
            color_dict_filtered[(row['latitude'], row['longitude'])] = color

        subdata_unique_coord = filtered_data[['name_ibge', 'latitude', 'longitude']].drop_duplicates()
        map_html = create_map(subdata_unique_coord, color_dict_filtered, colormap[selected_var], selected_var, variable_details)

    else:
        empty_data = pd.DataFrame(columns=['latitude', 'longitude'])
        map_html = create_map(empty_data, color_dict_filtered, colormap[selected_var], selected_var, variable_details)

    return map_html

# Histograms functions
def divide_dataset(df):
    """
    Divide the dataset into north, south, east, and west regions based on coordinates.

    Args:
    - df (pd.DataFrame): The DataFrame with geographical data.

    Returns:
    - list: List of DataFrames for north, south, east, and west regions.
    """
    # Extract latitude and longitude
    latitudes = df['latitude']
    longitudes = df['longitude']

    # Calculate the most northern, southern, eastern, and western coordinates
    most_north = latitudes.max()
    most_south = latitudes.min()
    most_east = longitudes.min()
    most_west = longitudes.max()

    # Calculate average latitude and longitude
    average_lat = (most_north + most_south) / 2
    average_long = (most_east + most_west) / 2

    # Split the data into north and south regions based on latitude
    north_data = df[df['latitude'] <= average_lat]
    south_data = df[df['latitude'] > average_lat]

    # Split the data into north and south regions based on longitudes
    east_data = df[df['longitude'] >= average_long]
    west_data = df[df['longitude'] < average_long]
    
    return [north_data, south_data, east_data, west_data]

# def update_histogram(selected_year, selected_season, selected_var, north_data_year, south_data_year, east_data_year, west_data_year):
#     fig = make_subplots(rows=1, cols=2, subplot_titles=('North vs South', 'East vs West'))

#     for direction, data_year in zip(['North', 'South', 'East', 'West'], [north_data_year, south_data_year, east_data_year, west_data_year]):
#         direction_var_season = data_year.get_group(selected_year)[data_year.get_group(selected_year)['season'] == selected_season][selected_var]

#         if direction in ['North', 'South']:
#             fig_num = 1
#             opposite_direction = 'South' if direction == 'North' else 'North'
#             # Set the color for North and South
#             color = 'blue' if direction == 'North' else 'orange'
#         else:
#             fig_num = 2
#             opposite_direction = 'West' if direction == 'East' else 'East'
#             # Set the color for East and West
#             color = 'green' if direction == 'East' else 'red'

#         fig.add_trace(go.Histogram(x=direction_var_season, name=direction, marker_color=color, opacity=0.4), row=1, col=fig_num)

#     fig.update_layout(
#         title=f'Year {selected_year}: {selected_var} Variation in Different Regions {selected_season}', 
#         xaxis_title=selected_var, 
#         yaxis_title='Events',
#         height = 600,
#         #width = 2200,
#         barmode = 'overlay'
#         )

#     return fig

# def update_histogram(selected_year, selected_season, selected_var, variable_details, north_data_year, south_data_year, east_data_year, west_data_year):
#     """
#     Update histograms for each region based on selected options.

#     Args:
#     - selected_year (str): Selected year.
#     - selected_season (str): Selected season.
#     - selected_var (str): Selected variable.
#     - variable_details (dict): Details about the variables.
#     - north_data_year (pd.DataFrame): North region data grouped by year.
#     - south_data_year (pd.DataFrame): South region data grouped by year.
#     - east_data_year (pd.DataFrame): East region data grouped by year.
#     - west_data_year (pd.DataFrame): West region data grouped by year.

#     Returns:
#     - plotly.graph_objs.Figure: Plotly figure with histograms for north vs south and east vs west.
#     """
#     fig = make_subplots(rows=1, cols=2, subplot_titles=('North vs South', 'East vs West'))

    
#     buttons = [
#         dict(label='Latitudes', method='update', args=[{'visible': [True, True, False, False]}]),
#         dict(label='Longitudes', method='update', args=[{'visible': [False, False, True, True]}]),
#         dict(label='Latitudes-Longitudes', method='update', args=[{'visible': [True, True, True, True]}]),
        
#     ]

#     fig.update_layout(updatemenus=[
#         dict(
#             type='buttons',
#             direction='down',
#             buttons=buttons,
#             x=1.0,
#             xanchor='right',
#             y=1.15,
#             yanchor='top'
#         )
#     ])

    
#     for direction, data_year in zip(['North', 'South', 'East', 'West'], [north_data_year, south_data_year, east_data_year, west_data_year]):
#         direction_var_season = data_year.get_group(selected_year)[data_year.get_group(selected_year)['season'] == selected_season][selected_var]

#         if direction in ['North', 'South']:
#             fig_num = 1
#             opposite_direction = 'South' if direction == 'North' else 'North'
#             # Set the color for North and South
#             color = 'blue' if direction == 'North' else 'orange'
#         else:
#             fig_num = 2
#             opposite_direction = 'West' if direction == 'East' else 'East'
#             # Set the color for East and West
#             color = 'green' if direction == 'East' else 'red'

#         num_bins = 100  # Number of bins to display
#         bin_width = (max(direction_var_season) - min(direction_var_season)) / num_bins  # Calculate the width of each bin
#         bins = [i * bin_width + min(direction_var_season) for i in range(num_bins + 1)]  # Generate bins based on width

#         fig.add_trace(go.Histogram(x=direction_var_season, name=direction, marker_color=color, opacity=0.4,
#                     xbins=dict(start=min(direction_var_season), end=max(direction_var_season), size=bin_width)), row=1, col=fig_num)

#     fig.update_layout(
#         title=f'Year {selected_year}: {selected_var} Variation in Different Regions {selected_season}', 
#         xaxis_title= f'{selected_var} - {variable_details[selected_var][0]} [{variable_details[selected_var][1]}]' , 
#         yaxis_title='Events',
#         height=600
#     )
    
#     return fig

def update_histogram(selected_year, selected_season, selected_var, variable_details, north_data_year, south_data_year, east_data_year, west_data_year):
    fig_north_south = go.Figure()
    fig_east_west = go.Figure()

    buttons_ns = [
        dict(label='Nort - South', method='update', args=[{'visible': [True, True]}]),
        dict(label='North', method='update', args=[{'visible': [True, False]}]),
        dict(label='South', method='update', args=[{'visible': [False, True]}]),   
    ]

    buttons_ew = [
        dict(label='East - West', method='update', args=[{'visible': [True, True]}]),
        dict(label='East', method='update', args=[{'visible': [True, False]}]),
        dict(label='West', method='update', args=[{'visible': [False, True]}]),    
    ]

    fig_north_south.update_layout(
        updatemenus=[
            dict(
                type='buttons',
                direction='down',
                buttons=buttons_ns,
                x=1.0,
                xanchor='right',
                y=1.15,
                yanchor='top'
            )
        ],
        title=f'North / South: Year {selected_year}, {selected_var} Variation in {selected_season}',
        xaxis_title=f'{selected_var} - {variable_details[selected_var][0]} [{variable_details[selected_var][1]}]',
        yaxis_title='Events'
    )

    fig_east_west.update_layout(
        updatemenus=[
            dict(
                type='buttons',
                direction='down',
                buttons=buttons_ew,
                x=1.0,
                xanchor='right',
                y=1.15,
                yanchor='top'
            )
        ],
        title=f'East / West: Year {selected_year}, {selected_var} Variation in {selected_season}',
        xaxis_title=f'{selected_var} - {variable_details[selected_var][0]} [{variable_details[selected_var][1]}]',
        yaxis_title='Events'
    )

    for direction, data_year, fig in zip(['North', 'South'], [north_data_year, south_data_year], [fig_north_south, fig_north_south]):
        direction_var_season = data_year.get_group(selected_year)[data_year.get_group(selected_year)['season'] == selected_season][selected_var]

        color = 'blue' if direction == 'North' else 'orange'

        num_bins = 100
        bin_width = (max(direction_var_season) - min(direction_var_season)) / num_bins
        bins = [i * bin_width + min(direction_var_season) for i in range(num_bins + 1)]

        fig.add_trace(
            go.Histogram(
                x=direction_var_season,
                name=direction,
                marker_color=color,
                opacity=0.4,
                xbins=dict(start=min(direction_var_season), end=max(direction_var_season), size=bin_width)
            )
        )

    for direction, data_year, fig in zip(['East', 'West'], [east_data_year, west_data_year], [fig_east_west, fig_east_west]):
        direction_var_season = data_year.get_group(selected_year)[data_year.get_group(selected_year)['season'] == selected_season][selected_var]

        color = 'green' if direction == 'East' else 'red'

        num_bins = 100
        bin_width = (max(direction_var_season) - min(direction_var_season)) / num_bins
        bins = [i * bin_width + min(direction_var_season) for i in range(num_bins + 1)]

        fig.add_trace(
            go.Histogram(
                x=direction_var_season,
                name=direction,
                marker_color=color,
                opacity=0.4,
                xbins=dict(start=min(direction_var_season), end=max(direction_var_season), size=bin_width)
            )
        )

    return fig_north_south, fig_east_west


def normalize_values(data, new_min=1, new_max=3):
    # Extract all values from the list of dictionaries
    #all_values = [list(data.values())[0] for data in list_dict for data in list_dict]
    # print(list_dict)

    # Stampa le somme dei valori per ciascuna colonna
    all_values = []
    for key, value in data.items():
        all_values.append(value)

    min_val = min(all_values)
    max_val = max(all_values)
    
    normalized = {}
    for key, value in data.items():
        normalized_value = new_min + (value - min_val) * (new_max - new_min) / (max_val - min_val)
        normalized[key] = normalized_value

    return normalized



def update_scatterplot(selected_var, variable_details, df, df_soja):
    yearly_productivity_means = {}

    # Elenca tutte le colonne del DataFrame df_soja e calcola la media dei valori per ciascuna colonna
    means_per_column = {col: df_soja[col].mean() for col in df_soja.columns[3:]}

    for year in df['year'].unique():
        year_productivity_mean = df_soja[df_soja[year] == year].mean()
        yearly_productivity_means[year] = year_productivity_mean
    # Elenca tutte le colonne del DataFrame df_soja e calcola la somma dei valori per ciascuna colonna
    year_productivity = {col: df_soja[col].sum() for col in df_soja.columns[3:]}

    
    mean_var = df.groupby(['year', 'season'])[selected_var].mean().reset_index()
    
#   from sklearn.preprocessing import MinMaxScaler

# # Example of how to use MinMaxScaler for normalization
# scaler = MinMaxScaler(feature_range=(1, 10))
# mean_var['normalized_productivity'] = scaler.fit_transform(mean_var[['year', 'season', selected_var]])


    # Normalize productivity values between 1 and 3
    normalized_productivity = normalize_values(year_productivity, new_min=5, new_max=15)

    # Aggiunta della colonna 'normalized_productivity' al DataFrame 'mean_var'
    mean_var['normalized_productivity'] = mean_var['year'].map(normalized_productivity)
    print(mean_var)
    scatter_fig = px.scatter(
        mean_var, 
        x='year', 
        y=selected_var, 
        color='season', 
        size= 'normalized_productivity',  # Utilizza la colonna 'normalized_productivity' come dimensione
        title=f'Mean {selected_var}[{variable_details[selected_var][1]}] - {variable_details[selected_var][0]}  by Season for Each Year',
        labels={selected_var: selected_var}#'Productivity'}# 'normalized_productivity': 'Normalized Productivity'}
    )

    scatter_fig.update_traces(marker=dict(size=12))
    scatter_fig.update_layout(
        updatemenus=[
            {
                'buttons': [
                    {
                        'method': 'restyle',
                        'label': 'All Seasons',
                        'args': [{'visible': [True] * len(mean_var['season'].unique())}]
                    },
                    *[
                        {
                            'method': 'restyle',
                            'label': season,
                            'args': [
                                {'visible': [True if s == season else False for s in mean_var['season']]}
                            ]
                        } for season in mean_var['season'].unique()
                    ]
                ],
                'direction': 'down',
                'showactive': True,
            }
        ],
        height=500
    )
    return scatter_fig




def create_dash(df, df_soja):
    """
    Create a Dash application for visualizing agroclimatology data.

    Args:
    - df (pd.DataFrame): The main DataFrame.
    - df_soja (pd.DataFrame): Secondary DataFrame for additional processing.

    Returns:
    - dash.Dash: The created Dash application.
    """
    # Retrieve all column names
    all_columns = df.columns.tolist()
    # Columns to be removed
    columns_to_remove = ['codigo_ibge', 'latitude', 'longitude', 'year', 'month', 'day', 'season', 'name_ibge']
    # Create a list of variables starting from the column of a DataFrame deleting some of them
    variables = [col for col in all_columns if col not in columns_to_remove]
    variable_details = {
        'TS': ['Earth Skin Temperature', '°C'],
        'PS' : ['Surface Preassure', '??'],
        'GWETROOT': ['Root Zone Soil Wetness','%'],
        #'Precipitation': 'mm',
        #'Wind_Speed': 'm/s',
        
    }
    
    # Create colormap and split dataset
    colormap = generate_colormaps(df, variables)
    # Divide dataset depending on the position of the measurement
    [north_data, south_data, east_data, west_data] = divide_dataset(df)
    # print(f'north_data : ', len(north_data))    #north_data :  777328
    # print(f'south_data : ', len(south_data))    # south_data :  1007458
    # print(f'east_data : ', len(east_data))  # east_data :  772214
    # print(f'west_data : ', len(west_data))   # west_data :  1012572
    # # Groupby each dataset for the year
    north_data_year = north_data.groupby('year') 
    south_data_year = south_data.groupby('year') 
    east_data_year = east_data.groupby('year')
    west_data_year = west_data.groupby('year')
    print(f'df = {df}')
    # Initialize the Dash app
    app = dash.Dash(__name__)
    # Define the layout of the dashboard
    app.layout = html.Div([
        html.H1("Agroclimatology - Paranà (Brazil)", style={'text-align': 'center', 'color': 'green'}),  # Centered header

       html.Div([
        # Dropdown for Year
        html.Div([
            html.Label('Select Year:', style={'padding': '10px 0'}),
            dcc.Dropdown(
                id='year-dropdown',
                options=[{'label': year, 'value': year} for year in df['year'].unique()],
                value=df['year'].min(),
                style={'width': '200px'}  # Adjust the width of the dropdown
            )
        ], style={'display': 'inline-block', 'padding-right': '20px'}),  # Style for Year dropdown
        # Dropdown for Month
        html.Div([
            html.Label('Select Month:', style={'padding': '10px 0'}),
            dcc.Dropdown(
                id='month-dropdown',
                options=[{'label': month, 'value': month} for month in df['month'].unique()],
                value=df['month'].min(),
                style={'width': '200px'}
            )
        ], style={'display': 'inline-block', 'padding-right': '20px'}),  # Style for Month dropdown
        # Dropdown for Day
        html.Div([
            html.Label('Select Day:', style={'padding': '10px 0'}),
            dcc.Dropdown(
                id='day-dropdown',
                options=[{'label': day, 'value': day} for day in df['day'].unique()],
                value=df['day'].min(),
                style={'width': '200px'}
            )
        ], style={'display': 'inline-block'})  # Style for Day dropdown
    ], style={'text-align': 'center', 'padding-bottom': '20px'}),  # Center the dropdowns and set padding        
        
        # Dropdown for selecting variable
        html.Div([
            html.Label('Select Varible:', style={'padding': '10px 0'}),
            dcc.Dropdown(
                id='var-dropdown',
                #options=[{'label': var, 'value': var} for var in variables],
                options=[
                    {'label': f'{var} - {variable_details[var][0]}', 'value': var, 'title': f'{var} - {variable_details[var][0]}'}
                    for var in variables
                ],
                value= variables[0],  # Initial value for the dropdown
                style={'width': '600px'}
            )
        ], style={'display': 'flex', 'justify-content': 'center', 'padding-bottom': '20px'}),

        # Map component
        html.Iframe(id='map-iframe', width='100%', height='500'),

        
        # Dropdown for selecting the season
        html.Div([
            html.Label('Select Season:', style={'padding': '10px 0'}),
            dcc.Dropdown(
                id='season-dropdown',
                options=[{'label': season, 'value': season} for season in df['season'].unique()],
                value='Winter',  # Initial value for the dropdown
                style={'width': '1000px'}
            )
        ], style={'display': 'flex', 'justify-content': 'center', 'padding-bottom': '20px'}),

        
        # Histograms plot
        dcc.Graph(
            id='lat-hist',
            config={'displayModeBar': False}
        ),

        dcc.Graph(
            id='long-hist',
            config={'displayModeBar': False}
        ),

        # Scatterplot
        dcc.Graph(
            id='scatter-plot',
            config={'displayModeBar': False}
        ), 
    ], style={'font-family': 'Arial, sans-serif', 'margin': '20px','background-color': 'white'})  # Define font-family and set margin for the entire layout

    # Update callback
    @app.callback(
        [Output('map-iframe', 'srcDoc'),
         Output('lat-hist', 'figure'),
         Output('long-hist', 'figure'),
         Output('scatter-plot', 'figure')],
        [Input('year-dropdown', 'value'),
         Input('month-dropdown', 'value'),
         Input('day-dropdown', 'value'),
         Input('season-dropdown', 'value'),
         Input('var-dropdown', 'value')]
    )

    
    def update_map_and_graph(selected_year, selected_month, selected_day, selected_season, selected_var):
        # Map:
        map_html = update_map(df, selected_year, selected_month, selected_day, selected_var, variable_details, colormap)
        
        # Histogram:
        # fig_NS, fig_EW = update_histogram(selected_year, selected_season, selected_var, north_data_year, south_data_year, east_data_year, west_data_year)
        fig_lat, fig_long= update_histogram(selected_year, selected_season, selected_var, variable_details, north_data_year, south_data_year, east_data_year, west_data_year)
        
        # Scatterplot
        scatter_fig = update_scatterplot(selected_var, variable_details, df, df_soja)
   
        return map_html, fig_lat, fig_long, scatter_fig
    
    return app
    


